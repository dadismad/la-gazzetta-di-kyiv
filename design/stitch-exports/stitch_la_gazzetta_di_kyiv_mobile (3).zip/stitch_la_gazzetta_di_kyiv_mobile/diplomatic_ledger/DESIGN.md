---
name: Diplomatic Ledger
colors:
  surface: '#fff7fe'
  surface-dim: '#dfd8de'
  surface-bright: '#fff7fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f1f8'
  surface-container: '#f3ecf2'
  surface-container-high: '#ede6ec'
  surface-container-highest: '#e8e0e7'
  on-surface: '#1d1b1f'
  on-surface-variant: '#4b444f'
  inverse-surface: '#332f34'
  inverse-on-surface: '#f6eef5'
  outline: '#7c7480'
  outline-variant: '#cdc3d0'
  surface-tint: '#715091'
  primary: '#482967'
  on-primary: '#ffffff'
  primary-container: '#604080'
  on-primary-container: '#d7b1fa'
  inverse-primary: '#ddb8ff'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#4a3400'
  on-tertiary: '#ffffff'
  tertiary-container: '#674900'
  on-tertiary-container: '#efb742'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#f0dbff'
  primary-fixed-dim: '#ddb8ff'
  on-primary-fixed: '#2a0749'
  on-primary-fixed-variant: '#583877'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#ffdea6'
  tertiary-fixed-dim: '#f7bd48'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5d4200'
  background: '#fff7fe'
  on-background: '#1d1b1f'
  surface-variant: '#e8e0e7'
typography:
  display-masthead:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '900'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system adopts a **Neo-Brutalist Classical** aesthetic. It blends the authoritative weight of historical statecraft with the stark, functional efficiency of modern digital ledgers. The personality is disciplined, archival, and uncompromisingly structural.

The visual narrative is driven by sharp geometries and intentional physical metaphors: heavy paper stock, struck-through ink, and gold leaf inlays used as rigid structural dividers rather than decorative flourishes. 

**Key Directives:**
- **Zero Softness:** No rounded corners or soft shadows are permitted. 
- **The Strike-through:** A signature horizontal gold line acts as a motif of "ratification" and "finality" across the masthead and key headers.
- **Archival Clarity:** High-contrast legibility takes precedence over visual fluff, evoking the feeling of a high-stakes treaty or a formal state record.

## Colors
The palette is rooted in historical prestige and legislative clarity.

- **Roman Purple (#604080):** Used exclusively for high-level branding, mastheads, and primary action surfaces. It represents the "State."
- **Gold (#D4AF37 / #B8860B):** These are structural colors. Gold is used for borders, rules, and "ratified" states. It provides the architectural framework for the ledger.
- **Warm Paper (#FAF9F6):** The foundational canvas. It reduces the harshness of pure white while maintaining an archival, physical presence.
- **Crimson (#8B0000):** Reserved for alerts, negative diplomacy, and critical errors. In the masthead, it provides the "ink" for the identity.
- **Charcoal & Slate:** Systematic neutrals used for body text and metadata respectively.

## Typography
The system utilizes a dual-font strategy to balance elegance with utility.

**Playfair Display** is used for headlines and branding. It evokes the history of the printing press and formal decrees. In the masthead, the "Diplomatic Ledger" text is rendered in Crimson, outlined in Gold, and bisected by a 2px horizontal Gold rule.

**Inter** provides the functional engine for the ledger. It is used for all data entry, list items, and descriptions to ensure maximum legibility at small sizes. All labels should be uppercase with slight tracking to maintain an institutional feel.

## Layout & Spacing
The layout follows a **Fixed-Column Ledger** model. Content is organized into rigid vertical stacks that expand horizontally on desktop but remain strictly vertically aligned on mobile.

- **The Masthead:** A full-width Roman Purple block (height: 80px) anchored at the top.
- **Expandable Rows:** All data entries occupy full-width rows. They use 1px Gold borders at the bottom to separate entries.
- **Rhythm:** A 4px baseline grid ensures vertical consistency.
- **Mobile Reflow:** On mobile devices, side-by-side data columns in a row should collapse into a single vertical stack, maintaining the 16px side margins.

## Elevation & Depth
This design system rejects all depth illusions. There are no shadows, blurs, or gradients.

**Hierarchy via Layering:**
- **Level 0:** Warm Paper background.
- **Level 1:** Primary containers/rows with 1px Gold (#B8860B) solid borders.
- **Level 2:** Roman Purple blocks used for active states or headers.
- **Focus States:** Instead of a shadow, a focus state is indicated by a 2px Crimson border or a solid Gold background fill with Charcoal text.

## Shapes
Sharpness is a core brand value. 

- All buttons, input fields, and containers must have **0px border radius**. 
- Structural dividers are solid 1px or 2px lines.
- No circles are permitted; even status indicators (e.g., "Online") should be rendered as small solid squares.

## Components

### Masthead
The primary identity block. Background is Roman Purple. The title "Diplomatic Ledger" is centered, using Crimson text with a Gold hairline outline. A 2px Gold line strikes through the exact center of the text horizontally, extending to the edges of the container.

### Expandable Ledger Rows
Rows occupy the full width of their container.
- **Default:** 1px Gold bottom border, Warm Paper background.
- **Expanded:** The background shifts to a very light Gold tint or remains Paper with a 2px Gold left-accent border. 
- **Interaction:** A simple "+" or "-" glyph in the far right column, rendered in Charcoal.

### Buttons
- **Primary:** Solid Roman Purple background, Gold text, 0px radius.
- **Secondary:** Transparent background, 1px Gold border, Charcoal text.
- **Critical:** Solid Crimson background, Gold text.

### Inputs
- **Text Fields:** 1px Gold bottom border only. On focus, the border thickens to 2px Crimson. Labels are "Inter Label-Bold" positioned above the field.

### Chips/Tags
- Rectangular boxes with 1px Gold borders. Text is Inter (Body-sm). No fill unless the state is "Active," in which case the fill is Gold with Charcoal text.

### Progress Bars
- Rendered as a "Ledger Scale." A horizontal 1px Gold track with a solid Roman Purple rectangular block representing progress.